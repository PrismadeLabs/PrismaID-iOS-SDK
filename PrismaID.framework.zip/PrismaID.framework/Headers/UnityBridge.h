//
//  UnityBridge.h
//  iossdk
//
//  Created by Zdenek Skalnik on 01/05/2019.
//  Copyright © 2019 Prismade Labs GmbH. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

    typedef void (*UnityCallbackFunction)(const char* onEvent, const char* response);

    void initialiseSDK(const char* apiKey, const char* serverURL, const BOOL twoFingerHoldingMode);
    void setGameObject(const char* gameObject);
    void unityTouch(const int phase, const int pointerId, const float x, const float y, const float radius);
    void setUnityDelegate(UnityCallbackFunction callback);
    
#ifdef __cplusplus
}
#endif
