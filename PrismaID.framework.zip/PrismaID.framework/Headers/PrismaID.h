//
//  Prismaid.h
//  Prismaid
//
//  Created by Zdenek Skalnik on 28/04/2019.
//  Copyright © 2019 Prismade Labs GmbH. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for iossdk.
FOUNDATION_EXPORT double PrismaIDVersionNumber;

//! Project version string for iossdk.
FOUNDATION_EXPORT const unsigned char PrismaIDVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <PrismaID/PublicHeader.h>
#import <PrismaID/UnityBridge.h>


